import { Appointmentform } from './appointmentform';

describe('Appointmentform', () => {
  it('should create an instance', () => {
    expect(new Appointmentform()).toBeTruthy();
  });
});
