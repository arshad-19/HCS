import { logging } from 'protractor';

export class Appointmentform {
    public  patientName:string;
    public contactNo:number;
   public slotID:string;
}
