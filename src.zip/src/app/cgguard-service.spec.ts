import { CgguardService } from './cgguard-service';

describe('CgguardService', () => {
  it('should create an instance', () => {
    expect(new CgguardService()).toBeTruthy();
  });
});
