import { Checkup } from './checkup';

describe('Checkup', () => {
  it('should create an instance', () => {
    expect(new Checkup()).toBeTruthy();
  });
});
