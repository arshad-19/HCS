export class Checkup {
    public testId:string;
    public testName:string;
    public amount:number;

}
