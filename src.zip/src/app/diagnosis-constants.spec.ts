import { DiagnosisConstants } from './diagnosis-constants';

describe('DiagnosisConstants', () => {
  it('should create an instance', () => {
    expect(new DiagnosisConstants()).toBeTruthy();
  });
});
