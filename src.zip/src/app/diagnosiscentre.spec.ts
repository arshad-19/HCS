import { Diagnosiscentre } from './diagnosiscentre';

describe('Diagnosiscentre', () => {
  it('should create an instance', () => {
    expect(new Diagnosiscentre()).toBeTruthy();
  });
});
