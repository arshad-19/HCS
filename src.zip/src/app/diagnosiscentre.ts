export class Diagnosiscentre {
    public centreId:string;
    public centreName:string;
    public address:string;
    public area:string;
    public city:string;
    public contact:string; 
}
