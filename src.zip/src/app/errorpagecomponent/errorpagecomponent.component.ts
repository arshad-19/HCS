import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-errorpagecomponent',
  templateUrl: './errorpagecomponent.component.html',
  styleUrls: ['./errorpagecomponent.component.css']
})
export class ErrorpagecomponentComponent implements OnInit {

  flag:boolean= true;
  constructor() {
  
   }

  ngOnInit() {


  }

}
