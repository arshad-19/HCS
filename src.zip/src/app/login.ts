export class Login {
  uname: string;
  pwd: string;
}
