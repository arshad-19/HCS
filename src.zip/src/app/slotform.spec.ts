import { Slotform } from './slotform';

describe('Slotform', () => {
  it('should create an instance', () => {
    expect(new Slotform()).toBeTruthy();
  });
});
