export class Slotform {

    public slotDate: string;
    public noOfApmts: number;
    public diagnosisTestId: string;

}
