import { Component, OnInit } from '@angular/core';
import { DiagnosisService } from '../diagnosis.service';

@Component({
  selector: 'app-viewuserappointment',
  templateUrl: './viewuserappointment.component.html',
  styleUrls: ['./viewuserappointment.component.css']
})
export class ViewuserappointmentComponent implements OnInit {

  contactNo:string;
  errorMsg:string;
   appointments:any=[];
   showflag=true;
 constructor(private diagnosisService:DiagnosisService) {}
  patientName:string;
ngOnInit(){
       let token = localStorage.getItem('token');
                if(token != null){
                       let contact = this.diagnosisService.decrypt(token.split("-")[0]);
                       this.patientName= contact;
               }

        
}

removeApmt(apmtId){
        this.diagnosisService.removeAppointment(apmtId).subscribe(data=>{this.appointments = this.appointments.
          filter(a=>a.apmtId != apmtId)},
       error=>this.errorMsg= error.error.message
);
}

viewHistory(){
  this.diagnosisService.viewUserAppointments(this.contactNo).subscribe(
    data=>{this.appointments= data;this.showflag=false;this.patientName=this.appointments[0].patientName;},
    error=>this.errorMsg= error.error.message);
}
}
