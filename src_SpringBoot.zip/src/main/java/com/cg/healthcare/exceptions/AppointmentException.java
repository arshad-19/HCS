package com.cg.healthcare.exceptions;

public class AppointmentException extends Exception{

	public AppointmentException() {
		super();
		
	}

	public AppointmentException(String arg0) {
		super(arg0);
		
	}

}
