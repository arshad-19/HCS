package com.cg.healthcare.exceptions;

public class DiagnosisException extends Exception {

	public DiagnosisException() {
		super();
		
	}

	public DiagnosisException(String arg0) {
		super(arg0);
	
	}

	
}
