package com.cg.healthcare.exceptions;

public class DiagnosisTestException extends Exception{

	public DiagnosisTestException() {
		super();
		
	}

	public DiagnosisTestException(String message) {
		super(message);
		
	}

	
}
