package com.cg.healthcare.exceptions;

public class LoginException extends Exception{

	public LoginException() {
		super();
		
	}

	public LoginException(String arg0) {
		super(arg0);
		
	}

	
}
