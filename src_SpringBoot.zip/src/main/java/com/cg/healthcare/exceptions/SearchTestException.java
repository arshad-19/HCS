package com.cg.healthcare.exceptions;

public class SearchTestException extends Exception {

	public SearchTestException() {
		super();
		
	}

	public SearchTestException(String message) {
		super(message);
		
	}

	
}
