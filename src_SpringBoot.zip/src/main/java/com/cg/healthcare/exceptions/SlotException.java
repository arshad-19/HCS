package com.cg.healthcare.exceptions;

public class SlotException extends Exception{

	public SlotException() {
		super();
		
	}

	public SlotException(String message) {
		super(message);
		
	}

	
}
